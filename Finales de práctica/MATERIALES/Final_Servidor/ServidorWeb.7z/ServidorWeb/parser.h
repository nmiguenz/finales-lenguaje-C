int parserLogEntry(char* path , ArrayList* pArrayListEmployee);
int parserService(char* path , ArrayList* pArrayListEmployee);
int parser_guardar(char* path ,char* auxTime,char* auxDate,char* auxName,char* auxMsg,char* auxEmail);
