#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#include "ArrayList.h"

int procesarInformacion(ArrayList* pLog, ArrayList* pService);

#endif // FUNCIONES_H_INCLUDED
